"""HostelWatt source package."""
