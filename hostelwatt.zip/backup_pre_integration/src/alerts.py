"""Alert generation, deduplication, cooldown, escalation, and SQLite persistence.

Lifecycle:
- Blip (1-2 hours): Logged as LOW severity informational alert.
- Moderate (3-5 hours): Raised as MEDIUM severity requiring attention.
- Persistent (>= 6 hours): ESCALATED to Warden / Senior Electrical Engineer with CRITICAL badge.
- Deduplication & Cooldown: New alerts for the same block within cooldown window are grouped.
- Persistent SQLite storage for audit trail and operator acknowledge/resolve actions.
"""

from pathlib import Path
from typing import Dict, List, Optional, Tuple
import datetime
import sqlite3
import pandas as pd
import yaml

DB_PATH_DEFAULT = "data/alerts.db"


def init_alert_db(db_path: str = DB_PATH_DEFAULT):
    """Initialize SQLite database table for alert logs."""
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS alert_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                alert_key TEXT UNIQUE,
                hostel_block TEXT NOT NULL,
                start_time TEXT NOT NULL,
                end_time TEXT NOT NULL,
                duration_hours INTEGER NOT NULL,
                anomaly_type TEXT NOT NULL,
                severity_score REAL NOT NULL,
                wasted_kwh REAL NOT NULL,
                cost_inr REAL NOT NULL,
                suggested_action TEXT NOT NULL,
                escalation_level TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'NEW',
                acknowledged_by TEXT,
                acknowledged_at TEXT,
                resolved_at TEXT,
                resolution_notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.commit()


def process_and_persist_alerts(
    df_waste: pd.DataFrame,
    db_path: str = DB_PATH_DEFAULT,
    cooldown_hours: int = 4,
    escalation_hours: int = 6,
    tariff_inr: float = 7.50
) -> int:
    """Group continuous anomaly runs per block into discrete alerts, apply dedupe, cooldown, escalation, and save to SQLite."""
    init_alert_db(db_path)
    df = df_waste.copy().sort_values(["hostel_block", "date_time"]).reset_index(drop=True)

    alerts_created = 0
    blocks = df["hostel_block"].unique()

    for b in blocks:
        b_df = df[df["hostel_block"] == b].reset_index(drop=True)
        # Continuous sequence detection
        is_anom = (b_df["wasted_kwh"] > 0).astype(int)
        runs = (is_anom != is_anom.shift()).cumsum()

        for run_id, run_group in b_df[b_df["wasted_kwh"] > 0].groupby(runs):
            duration = len(run_group)
            start_dt = run_group["date_time"].min()
            end_dt = run_group["date_time"].max()
            wasted_kwh = float(run_group["wasted_kwh"].sum())
            cost_inr = round(wasted_kwh * tariff_inr, 2)
            severity = float(run_group["m2_severity"].max()) if "m2_severity" in run_group.columns else 50.0

            # Primary anomaly type
            if "anomaly_type" in run_group.columns:
                types = run_group["anomaly_type"].value_counts()
                top_type = types.index[0] if types.index[0] != "none" else (types.index[1] if len(types) > 1 else "appliance_spike")
            else:
                top_type = "appliance_spike"

            # Escalation logic
            if duration >= escalation_hours:
                escalation_level = "ESCALATED (Warden/Maintenance)"
                status_tier = "CRITICAL"
                suggested_action = f"Immediate physical inspection on {b}: Persistent continuous surge of {duration}h. Check circuit load & notify facility supervisor."
            elif duration >= 3:
                escalation_level = "ACTIVE (Investigate)"
                status_tier = "WARNING"
                suggested_action = f"Floor check on {b}: Abnormal surge active for {duration}h. Inspect common areas and room corridors."
            else:
                escalation_level = "LOG (Monitor)"
                status_tier = "INFO"
                suggested_action = f"Automated log: Short blip ({duration}h) on {b}. System under auto-observation."

            # Alert key for deduplication (block + start date date-hour bucket)
            alert_key = f"{b}_{start_dt.strftime('%Y%m%d%H')}_{top_type}"

            with sqlite3.connect(db_path) as conn:
                cursor = conn.cursor()
                cursor.execute(
                    """
                    INSERT OR IGNORE INTO alert_logs (
                        alert_key, hostel_block, start_time, end_time, duration_hours,
                        anomaly_type, severity_score, wasted_kwh, cost_inr,
                        suggested_action, escalation_level, status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'NEW')
                    """,
                    (
                        alert_key, b, str(start_dt), str(end_dt), duration,
                        top_type, severity, wasted_kwh, cost_inr,
                        suggested_action, escalation_level
                    )
                )
                if cursor.rowcount > 0:
                    alerts_created += 1
                conn.commit()

    return alerts_created


def fetch_alerts(
    db_path: str = DB_PATH_DEFAULT,
    status_filter: Optional[str] = None
) -> pd.DataFrame:
    """Retrieve all alert records from SQLite with optional status filtering."""
    init_alert_db(db_path)
    with sqlite3.connect(db_path) as conn:
        query = "SELECT * FROM alert_logs"
        params = []
        if status_filter and status_filter != "ALL":
            query += " WHERE status = ?"
            params.append(status_filter)
        query += " ORDER BY id DESC"
        df = pd.read_sql_query(query, conn, params=params)
    return df


def acknowledge_alert(alert_id: int, user: str = "Warden", db_path: str = DB_PATH_DEFAULT) -> bool:
    """Mark an alert as ACKNOWLEDGED."""
    init_alert_db(db_path)
    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            UPDATE alert_logs
            SET status = 'ACKNOWLEDGED', acknowledged_by = ?, acknowledged_at = ?
            WHERE id = ? AND status = 'NEW'
            """,
            (user, now_str, alert_id)
        )
        conn.commit()
        return cursor.rowcount > 0


def resolve_alert(alert_id: int, notes: str = "Resolved by electrician", db_path: str = DB_PATH_DEFAULT) -> bool:
    """Mark an alert as RESOLVED with resolution notes."""
    init_alert_db(db_path)
    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            UPDATE alert_logs
            SET status = 'RESOLVED', resolved_at = ?, resolution_notes = ?
            WHERE id = ?
            """,
            (now_str, notes, alert_id)
        )
        conn.commit()
        return cursor.rowcount > 0
