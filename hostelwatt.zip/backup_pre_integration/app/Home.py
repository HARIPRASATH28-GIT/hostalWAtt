"""HostelWatt: AI-Powered Hostel Electricity Anomaly Detection Dashboard.

Main Landing Page & System Overview.
"""

import sys
from pathlib import Path
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import yaml

# Ensure project root is in path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from app.ui_utils import apply_custom_css, render_header, render_metric_card, get_plotly_theme
from src.synth import generate_hostel_dataset
from backend.database import get_monitoring_stats, get_live_alerts
from backend.scheduler import scheduler_instance

st.set_page_config(
    page_title="HostelWatt - Overview",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

apply_custom_css()
render_header(
    title="HostelWatt Energy Intelligence",
    subtitle="Continuous AI-driven electrical anomaly monitoring, avoidable cost estimation & peak demand safeguard for student blocks",
    icon="⚡",
)

# Live Monitoring Status Banner
sched_status = scheduler_instance.get_status()
m_stats = get_monitoring_stats()
is_sched_running = sched_status["is_running"]

st.markdown(
    f"""
    <div style="background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(99, 102, 241, 0.3); border-radius: 10px; padding: 0.75rem 1.25rem; margin-bottom: 1.25rem; display: flex; justify-content: space-between; align-items: center;">
        <div style="display: flex; align-items: center; gap: 0.75rem;">
            <span style="background: {'#22c55e' if is_sched_running else '#ef4444'}; color: #fff; font-size: 0.75rem; font-weight: 800; padding: 0.2rem 0.5rem; border-radius: 4px;">
                ● BACKEND {'RUNNING' if is_sched_running else 'STOPPED'}
            </span>
            <span style="background: #3b82f6; color: #fff; font-size: 0.75rem; font-weight: 800; padding: 0.2rem 0.5rem; border-radius: 4px;">
                [SIMULATED METER TELEMETRY]
            </span>
            <span style="color: #cbd5e1; font-size: 0.88rem;">
                Polling interval: <strong>{sched_status['interval_seconds']}s</strong> ({sched_status['mode']} mode) | Active Alerts: <strong style="color: #f87171;">{m_stats['new_alerts']}</strong>
            </span>
        </div>
        <div>
            <a href="/Live_Monitoring" target="_self" style="text-decoration: none; background: #6366f1; color: #fff; font-size: 0.8rem; font-weight: 700; padding: 0.35rem 0.75rem; border-radius: 6px;">
                View Live Telemetry ➜
            </a>
        </div>
    </div>
    """,
    unsafe_allow_html=True
)

# Load config
with open(ROOT_DIR / "config.yaml", "r", encoding="utf-8") as f:
    config = yaml.safe_load(f)

tariff_inr = config["tariff"]["energy_rate_inr_per_kwh"]


# Load cached data
@st.cache_data
def load_all_data():
    blocks_file = ROOT_DIR / "data" / "synthetic" / "hostel_blocks.parquet"
    if not blocks_file.exists():
        df_b, _ = generate_hostel_dataset(str(ROOT_DIR / "config.yaml"))
        return df_b
    return pd.read_parquet(blocks_file)

df_all = load_all_data()

# Calculations for Current Month (latest 30 days)
latest_date = df_all["date_time"].max()
month_start = latest_date - pd.Timedelta(days=30)
df_month = df_all[df_all["date_time"] >= month_start].copy()

total_blocks = df_all["hostel_block"].nunique()
active_anomalies_count = int(df_month["is_anomaly"].sum())

# Avoidable energy waste and cost estimate
wasted_kwh_month = df_month[df_month["is_anomaly"] == 1]["injected_extra_kwh"].clip(lower=0).sum()
cost_saved_inr = wasted_kwh_month * tariff_inr

# Maximum Demand (MD) lower-bound calculation for current month
hourly_system_demand = df_month.groupby("date_time")["energy_kwh"].sum()
system_md_kw = hourly_system_demand.max()

# Top KPI Cards
c1, c2, c3, c4 = st.columns(4)
with c1:
    render_metric_card("Monitored Blocks", f"{total_blocks}", "5 Residential Wings")
with c2:
    render_metric_card("Active Anomaly Hours", f"{active_anomalies_count:,} hrs", "Last 30-day window", status="warning")
with c3:
    render_metric_card("Est. Waste This Month", f"{wasted_kwh_month:,.1f} kWh", f"₹ {cost_saved_inr:,.0f} Avoidable Cost (Est.)", status="critical")
with c4:
    render_metric_card("System Peak MD (Est.)", f"{system_md_kw:,.1f} kW", f"Lower-bound @ {hourly_system_demand.idxmax():%d %b %H:00}")

st.markdown(
    """
    <div class="disclaimer-banner">
        ℹ️ <strong>Engineering Note:</strong> All financial and kilowatt-hour figures are estimates based on baseline regression models.
        Maximum Demand is calculated from hourly energy readings and represents an <strong>engineering lower bound</strong> of actual utility 15-minute billing demand.
    </div>
    """,
    unsafe_allow_html=True,
)

# Block Status Section
st.markdown("### 🏢 Block Health & Operational Status")

block_summaries = []
for b_id, b_df in df_month.groupby("hostel_block"):
    anom_hours = b_df["is_anomaly"].sum()
    b_waste = b_df[b_df["is_anomaly"] == 1]["injected_extra_kwh"].clip(lower=0).sum()
    b_peak = b_df["energy_kwh"].max()

    # Status classification rule
    if anom_hours > 40 or b_waste > 200:
        status_label = "CRITICAL"
        status_class = "status-critical"
    elif anom_hours > 15 or b_waste > 80:
        status_label = "WARNING"
        status_class = "status-warning"
    else:
        status_label = "NORMAL"
        status_class = "status-normal"

    block_summaries.append({
        "id": b_id,
        "name": [b["name"] for b in config["blocks"] if b["id"] == b_id][0],
        "rooms": b_df["room_count"].iloc[0],
        "avg_kw": round(b_df["energy_kwh"].mean(), 2),
        "peak_kw": round(b_peak, 2),
        "anom_hours": anom_hours,
        "waste_kwh": round(b_waste, 1),
        "waste_inr": round(b_waste * tariff_inr, 0),
        "status": status_label,
        "status_class": status_class,
    })

b_cols = st.columns(len(block_summaries))
for idx, b_info in enumerate(block_summaries):
    with b_cols[idx]:
        st.markdown(
            f"""
            <div class="metric-card" style="min-height: 220px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                    <span style="font-weight: 700; color: #f1f5f9; font-size: 1.05rem;">{b_info['id']}</span>
                    <span class="status-badge {b_info['status_class']}">{b_info['status']}</span>
                </div>
                <div style="color: #94a3b8; font-size: 0.8rem; margin-bottom: 0.75rem;">{b_info['name']}</div>
                <div style="font-size: 0.85rem; color: #cbd5e1; line-height: 1.7;">
                    <div>Rooms: <strong>{b_info['rooms']}</strong></div>
                    <div>Avg Load: <strong>{b_info['avg_kw']} kW</strong></div>
                    <div>Peak Load: <strong>{b_info['peak_kw']} kW</strong></div>
                    <div>Anomaly Hours: <strong style="color: #f87171;">{b_info['anom_hours']} hrs</strong></div>
                    <div style="margin-top: 0.35rem; padding-top: 0.35rem; border-top: 1px solid rgba(255,255,255,0.06);">
                        Est. Waste: <strong>₹ {b_info['waste_inr']:,.0f}</strong>
                    </div>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

st.markdown("---")

# Quick Visualizations: 7-day load comparison across blocks and anomaly breakdown
col_left, col_right = st.columns([7, 5])

with col_left:
    st.markdown("#### ⚡ Recent 7-Day Block Consumption Trend")
    last_7_days = df_all[df_all["date_time"] >= latest_date - pd.Timedelta(days=7)]

    fig = px.line(
        last_7_days,
        x="date_time",
        y="energy_kwh",
        color="hostel_block",
        labels={"date_time": "Time", "energy_kwh": "Load (kWh = avg kW)", "hostel_block": "Block"},
        template="plotly_dark",
        color_discrete_sequence=["#38bdf8", "#818cf8", "#c084fc", "#f472b6", "#fb923c"],
    )
    theme = get_plotly_theme()
    fig.update_layout(**theme["layout"])
    fig.update_layout(height=340, hovermode="x unified", legend=dict(orientation="h", y=1.12, x=0))
    st.plotly_chart(fig, use_container_width=True)

with col_right:
    st.markdown("#### 🚨 Anomaly Distribution by Type (Last 30 Days)")
    anom_type_counts = (
        df_month[df_month["anomaly_type"] != "none"]
        .groupby("anomaly_type")["injected_extra_kwh"]
        .agg(["count", "sum"])
        .reset_index()
    )
    anom_type_counts["sum"] = anom_type_counts["sum"].clip(lower=0)

    fig_pie = px.pie(
        anom_type_counts,
        names="anomaly_type",
        values="sum",
        hole=0.45,
        template="plotly_dark",
        color_discrete_sequence=["#f87171", "#fb923c", "#facc15", "#4ade80", "#a78bfa"],
    )
    fig_pie.update_layout(**theme["layout"])
    fig_pie.update_layout(height=340, margin=dict(t=20, b=20, l=10, r=10))
    fig_pie.update_traces(textposition="inside", textinfo="percent+label")
    st.plotly_chart(fig_pie, use_container_width=True)

# Navigation Quick Links
st.markdown("---")
st.markdown("#### 🧭 System Navigation")
nav1, nav2, nav3, nav4 = st.columns(4)
with nav1:
    st.info("**📈 Block Explorer**\n\nDeep-dive into time-series data with actual vs. expected predictions and heatmaps.")
with nav2:
    st.warning("**🚨 Anomalies & Alerts**\n\nView ranked incident log, filter by severity, and acknowledge/resolve live alerts.")
with nav3:
    st.success("**💰 Savings & ROI**\n\nQuantify avoidable kWh/INR losses and model IoT submetering payback periods.")
with nav4:
    st.info("**🔍 Room Localization**\n\nIsolate appliance signatures (kettles, immersion rods) down to demo block rooms.")
